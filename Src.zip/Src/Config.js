const API_BASE_URL = "http://192.168.11.29:8000/api";

export default API_BASE_URL;
